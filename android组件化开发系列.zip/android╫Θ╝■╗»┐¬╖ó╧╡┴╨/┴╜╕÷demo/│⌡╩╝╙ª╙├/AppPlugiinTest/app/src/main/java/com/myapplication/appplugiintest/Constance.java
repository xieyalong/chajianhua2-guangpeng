package com.myapplication.appplugiintest;

public class Constance {

    public static final String ACTIVITY_URL_MAIN = "/myapplication/appplugiintest/MainActivity";
    public static final String ACTIVYTY_URL_FRAGMENT = "/myapplication/appplugiintest/MainFragment";


    public static final String ACTIVITY_URL_SIMPLE = "/myapplication/appplugiintest/SimpleActivity";
    public static final String ACTIVITY_URL_CONTENT = "/content/contentPlugin/ContentActivity";
    public static final String ACTIVITY_URL_LOGIN = "/login/loginPlugin/LoginMainActivity";
    public static final String ACTIVITY_URL_INIT ="/initdata/initdataPlugin/InitDataMainActivity";
    public static final String ACTIVYTY_URL_FIRSTMAIN = "/firstMainMoudle/firstMainMoudlePlugin/MainActivity";


}
