package com.myapplication.appplugiintest;

import android.app.Application;
import android.util.Log;

import com.alibaba.android.arouter.launcher.ARouter;

/**
 * 自定义application，需要在AndroidManifest文件中配置自定义的application
 * 只需要在壳app中初始化即可
 */
public class HomeApplication extends Application {

    /**
     * ARouter框架是分组管理，按需加载。
     * 提起来很高深的样子呢！其实解释起来就是，
     * 在编译期框架扫描了所有的注册页面／服务／字段／拦截器等，
     * 那么很明显运行期不可能一股脑全部加载进来，这样就太不和谐了。
     * 所以就分组来管理，ARouter在初始化的时候只会一次性地加载所有的root结点，
     * 而不会加载任何一个Group结点，这样就会极大地降低初始化时加载结点的数量。
     * 比如某些Activity分成一组，组名就叫test，
     * 然后在第一次需要加载组内的某个页面时再将test这个组加载进来。
     */


    //ARouter调试开关
    private boolean isDebugARouter = true;


    @Override
    public void onCreate() {
        super.onCreate();

        if (isDebugARouter){
            //下面两行代码必须写在init前面，不然这些配置在init过程中无效
            ARouter.openLog();//打印日志
            //开启调试模式（如果实在instantRun模式下运行必须开启调试模式
            // 线上版本需要关闭，否则有安全风险）
            ARouter.openDebug();//
        }
        //初始化ARouter，官方推荐在application中初始化
        ARouter.init(HomeApplication.this);
        Log.d("HomeApplication","初始化完成");
    }

    @Override
    public void onTerminate() {
        super.onTerminate();

        //释放资源
        ARouter.getInstance().destroy();
    }
}
