package com.myapplication.appplugiintest;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.alibaba.android.arouter.facade.annotation.Route;
//自定义分组需要在增加group字段,一般默认情况下路径的第一个/  /之间是分组
@Route(path = Constance.ACTIVYTY_URL_FRAGMENT,group = "fragmentGroup")
public class MainFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragmentlayout,container,false);
        return view;
    }
}
