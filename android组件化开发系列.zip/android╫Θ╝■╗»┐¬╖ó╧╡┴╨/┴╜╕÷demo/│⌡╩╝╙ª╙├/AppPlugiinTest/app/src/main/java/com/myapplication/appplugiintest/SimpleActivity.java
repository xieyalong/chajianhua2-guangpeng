package com.myapplication.appplugiintest;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.alibaba.android.arouter.launcher.ARouter;

@Route(path = Constance.ACTIVITY_URL_SIMPLE)
public class SimpleActivity extends BaseActivity {

    @Autowired
    int key3;

    @Autowired
    String key4;

    private TextView textView;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.simplelayout);

        textView = findViewById(R.id.simp_text);
        textView.requestFocus();
        textView.setFocusable(true);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                setResult(46);
                finish();
            }
        });

//        Bundle bu = getIntent().getBundleExtra("testBu");
//        textView.setText("key3 = "+bu.getInt("key3")+"..........."+"key4="+bu.getString("key4"));
    }

}
