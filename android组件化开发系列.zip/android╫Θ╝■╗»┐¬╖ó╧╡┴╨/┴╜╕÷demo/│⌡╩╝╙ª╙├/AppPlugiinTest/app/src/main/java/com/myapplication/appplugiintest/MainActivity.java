package com.myapplication.appplugiintest;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.alibaba.android.arouter.facade.Postcard;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.alibaba.android.arouter.facade.callback.NavigationCallback;
import com.alibaba.android.arouter.launcher.ARouter;
import com.myapplication.databeanutils.UserInfoTestBean;


//在支持路由的界面上配置注解
//这里的路径需要注意的是至少要两级  /XX/XX
@Route(path = Constance.ACTIVITY_URL_MAIN)
public class MainActivity extends BaseActivity {

    private Button mBtn;
    private UserInfoTestBean userInfoTestBean;
    private FragmentTransaction transaction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mainlayout);

        mBtn = findViewById(R.id.main_btn_id);
        transaction = getSupportFragmentManager().beginTransaction();

        mBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


//                测试创建各个moudle流程
//                测试各个moudle生成maven库文件的脚本
//                测试在助app中引入各个moudle 库文件的配置
//                测试ARouter在组件化开发中的应用（需要在每个moudle中进行相关的配置并将相关的类注入到路由中
//                但是初始化需要在助app中进行）
//                测试各个moudle相互引用，界面的跳转、传参等

                /**
                 * 普通跳转（无传参）
                 * 组件之间通信的方式之一
                 */
//                ARouter.getInstance().build(Constance.ACTIVITY_URL_CONTENT).navigation();
//                ARouter.getInstance().build(Constance.ACTIVYTY_URL_FIRSTMAIN).navigation();
//                ARouter.getInstance().build(Constance.ACTIVITY_URL_SIMPLE).navigation();
//                ARouter.getInstance().build(Constance.ACTIVITY_URL_INIT).navigation();

//                跳转fragment，在fragment里面测试了自定义分组
//                MainFragment mainFragment = (MainFragment)ARouter.getInstance().build(Constance.ACTIVYTY_URL_FRAGMENT,"fragmentGroup").navigation();
//                transaction.add(R.id.main_id,mainFragment).commit();

//                Uri uri = Uri.parse(Constance.ACTIVITY_URL_CONTENT);
//                ARouter.getInstance().build(uri).navigation();
//                finish();//此处销毁activity不会再次返回该界面


                /**
                 * 传参,注意：注解传参每个moudle的参数key值不可以一样，否则后面的moudle
                 * 接受不到传的值
                 */
//                        （1）在first moudle测试了gradle脚本生成maven库文件
//                        并测试了注解传参不同的moudle参数key值不可以一致
//                        ARouter.getInstance().build(Constance.ACTIVYTY_URL_FIRSTMAIN)
//                                .withInt("data1",10)
//                                .withString("str1","传参")
//                                .navigation();

//                         （2）在login module测试注解传参，传对象
//                userInfoTestBean = new UserInfoTestBean("张三","男",10);
//                ARouter.getInstance().build(Constance.ACTIVITY_URL_LOGIN)
//                        .withInt("key3",56)
//                        .withString("key4","hh")
//                        .withParcelable("userInfo",(Parcelable) userInfoTestBean)
//                        .navigation();

//                （3）Bundle传参
//                Bundle bundle = new Bundle();
//                bundle.putInt("key3",4);
//                bundle.putString("key4","test");
//                ARouter.getInstance().build(Constance.ACTIVITY_URL_SIMPLE)
//                        .withBundle("testBu",bundle)
//                        .navigation();

//                startActivityForResult（）在ARouter框架中的实现
//                Bundle bundle = new Bundle();
//                bundle.putInt("key3",4);
//                bundle.putString("key4","test");
//                ARouter.getInstance().build(Constance.ACTIVITY_URL_SIMPLE)
//                        .withBundle("testBu",bundle)
//                        .navigation(MainActivity.this,123);


//                与databeanutils一起共同测试ARouter拦截器的应用
//                Bundle bundle = new Bundle();
//                bundle.putInt("key3",4);
//                bundle.putString("key4","test");
//                ARouter.getInstance().build(Constance.ACTIVITY_URL_SIMPLE)
//                        .withBundle("testBu",bundle)
//                        .navigation(MainActivity.this, new NavigationCallback() {
//                            @Override
//                            public void onFound(Postcard postcard) {
//

//                                Log.d("MainActivity","ARouter onFound 路由目标被发现时调用");
//                            }
//
//                            @Override
//                            public void onLost(Postcard postcard) {
//
//                                Log.d("MainActivity","ARouter onLost 路由到达之后调用");
//                            }
//
//                            @Override
//                            public void onArrival(Postcard postcard) {
//
//                                Log.d("MainActivity","ARouter onArrival 路由被丢失时调用");
//
//                            }
//
//                            @Override
//                            public void onInterrupt(Postcard postcard) {
//
//                                Log.d("MainActivity","ARouter onInterrupt 路由被拦截时调用");
//
//                            }
//                        });




//                （4）在content moudle中测试了bundle，注解，常规获得传参
//                并测试了moudle独自编辑的配置方法
//                ARouter.getInstance().build(Constance.ACTIVITY_URL_CONTENT)
//                        .withBundle("testBu",bundle)
//                        .navigation();


//                在initdatamoudle中测试暴露接口的应用



            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 123 && resultCode == 46){
            Log.d("MainActivity","onActivityResult success");
        }
    }
}
