package com.myapplication.login.library;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.alibaba.android.arouter.launcher.ARouter;
import com.myapplication.databeanutils.UserInfoTestBean;

@Route(path = "/login/loginPlugin/LoginMainActivity")
public class LoginMainActivity extends AppCompatActivity {

    private Button mBtn;
    //注解解析传参数需要key值与传参key值一至
    //必须为public类型 & 需要在onCreate中调用ARouter.getInstance().inject(this);配合使用
    //bundle， getIntent().getIntExtra()常规解析传参则不需要做上面步骤
    @Autowired(name = "key3")
    public int key3;
    @Autowired(name = "key4")
    public String key4;
    @Autowired(name = "userInfo")
    public UserInfoTestBean userInfo;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ARouter.getInstance().inject(this);
        setContentView(R.layout.librarylayout);


        mBtn = findViewById(R.id.login_btn);
        Toast.makeText(LoginMainActivity.this,"查看参数传递：key3="+key3+"key4="+key4,Toast.LENGTH_SHORT).show();
        Log.d("loginPlagin","查看userinfo：name="+userInfo.getName()+"sex="+userInfo.getSex()+"age="+userInfo.getAge());
        mBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //普通无参跳转
                ARouter.getInstance().build(LoginConstance.LOGIN_URL_CONTENT).navigation();
            }
        });
    }
}
