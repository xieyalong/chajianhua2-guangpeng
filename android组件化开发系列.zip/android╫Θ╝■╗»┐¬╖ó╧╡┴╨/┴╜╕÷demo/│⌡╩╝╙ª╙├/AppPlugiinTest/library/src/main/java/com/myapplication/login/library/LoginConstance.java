package com.myapplication.login.library;

public class LoginConstance {

    public static final String LOGIN_URL_CONTENT = "/content/contentPlugin/ContentActivity";
}
