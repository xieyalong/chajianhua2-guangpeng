package com.myapplication.content;


import android.app.Application;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;
import android.widget.Toast;

import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.alibaba.android.arouter.launcher.ARouter;

import org.w3c.dom.Text;

//D:\repository\content
@Route(path = "/content/contentPlugin/ContentActivity")
public class ContentActivity extends AppCompatActivity {

    private int key3;
    private String key4;
    private TextView textView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
//        moudle作为maven库文件如果将该activity注入路由框架只需要ARouter.getInstance().inject(this);
//        但是moudle单独编辑的话想将该activity注入路由框架需要对路由框架进行舒适化之后再注入，否则报空指针
//        ARouter.init(getApplication());
//        ARouter.getInstance().inject(this);
        setContentView(R.layout.contentlayout);

        key3 = getIntent().getIntExtra("key3",3);
        key4 = getIntent().getStringExtra("key4");
        textView = findViewById(R.id.content_text);

        textView.setText("查看传值：key3="+key3+";key4="+key4);

        //Bundle传参无需上面将当前activity注入路由中，但是路由注解传参则需要将当前activity注入路由
//        Bundle bu = getIntent().getBundleExtra("testBu");
//        if(bu != null){
//            Toast.makeText(this,"查看传值：key3="+bu.getInt("key3")+";key4="+bu.getString("key4"),Toast.LENGTH_SHORT).show();
//        }
    }
}
