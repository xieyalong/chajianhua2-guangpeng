package com.myapplication.databeanutils;


public class DataBeanUtilsConstance {

    public static final String URL_UTILS_USERINFO = "/databeanutils/databeanutilsPlugin/UserInfoTestBean";
}
