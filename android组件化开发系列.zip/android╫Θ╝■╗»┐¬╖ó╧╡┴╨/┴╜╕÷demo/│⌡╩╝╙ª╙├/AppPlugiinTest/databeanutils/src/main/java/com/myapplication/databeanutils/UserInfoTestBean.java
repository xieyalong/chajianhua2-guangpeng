package com.myapplication.databeanutils;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;
import com.google.gson.Gson;

public class UserInfoTestBean implements Parcelable {

    private String name;
    private String sex;
    private int age;
    private Gson gson;

    public UserInfoTestBean(){}
    public UserInfoTestBean(String name, String sex, int age){

        this.name = name;
        this.sex = sex;
        this.age = age;

    }

    protected UserInfoTestBean(Parcel in) {
        name = in.readString();
        sex = in.readString();
        age = in.readInt();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(sex);
        dest.writeInt(age);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<UserInfoTestBean> CREATOR = new Creator<UserInfoTestBean>() {
        @Override
        public UserInfoTestBean createFromParcel(Parcel in) {
            return new UserInfoTestBean(in);
        }

        @Override
        public UserInfoTestBean[] newArray(int size) {
            return new UserInfoTestBean[size];
        }
    };

    public void testMeth1(){
        Log.d("databeanutils","testMeth1 success");
    }

    private void testMeth2(){
        Log.d("databeanutils","testMeth2 success");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }


}
