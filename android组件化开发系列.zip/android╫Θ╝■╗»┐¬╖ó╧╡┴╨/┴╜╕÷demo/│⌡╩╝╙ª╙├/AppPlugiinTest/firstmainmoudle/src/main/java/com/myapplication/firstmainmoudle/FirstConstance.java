package com.myapplication.firstmainmoudle;

public class FirstConstance {
    public static final String INITDATA_URL_MEAU = "/firstMainMoudle/firstMainMoudlePlugin/MyMeau";
}
