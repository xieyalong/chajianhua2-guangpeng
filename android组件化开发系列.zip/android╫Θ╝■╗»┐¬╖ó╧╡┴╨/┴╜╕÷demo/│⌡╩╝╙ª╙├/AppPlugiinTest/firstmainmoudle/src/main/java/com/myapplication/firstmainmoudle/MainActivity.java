package com.myapplication.firstmainmoudle;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.alibaba.android.arouter.facade.annotation.Autowired;
import com.alibaba.android.arouter.facade.annotation.Route;
import com.alibaba.android.arouter.launcher.ARouter;

@Route(path = "/firstMainMoudle/firstMainMoudlePlugin/MainActivity")
public class MainActivity extends AppCompatActivity {

    @Autowired(name = "data1")
    public int data1;
    @Autowired(name = "str1")
    public String str1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ARouter.getInstance().inject(this);
        setContentView(R.layout.activity_main);
        Toast.makeText(this,"查看传参：data1="+data1+"====="+"str1="+str1,Toast.LENGTH_SHORT).show();
    }
}
